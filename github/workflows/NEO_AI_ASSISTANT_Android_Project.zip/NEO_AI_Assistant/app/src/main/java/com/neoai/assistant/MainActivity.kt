package com.neoai.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFFF8F0FF)
private val Purple = Color(0xFF5B20E6)
private val Blue = Color(0xFF249FE8)
private val Pink = Color(0xFFF28BD5)
private val TextDark = Color(0xFF17183B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NeoApp() }
    }
}

@Composable
fun NeoApp() {
    var page by remember { mutableStateOf("Home") }
    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        when (page) {
            "Chat" -> ChatScreen { page = it }
            "Settings" -> SettingsScreen { page = it }
            else -> HomeScreen { page = it }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String, onBack: (() -> Unit)? = null) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            TextButton(onClick = onBack) { Text("‹", fontSize = 38.sp, color = Purple) }
            Spacer(Modifier.width(8.dp))
        }
        Column {
            Text(title, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = TextDark)
            Text(subtitle, fontSize = 15.sp, color = Color(0xFF7D76A8))
        }
    }
}

@Composable
fun HomeScreen(nav: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("NEO AI", "Your smart AI companion")
        Card(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp),
            shape = RoundedCornerShape(28.dp),
            colors = CardDefaults.cardColors(Color.White.copy(alpha = .82f))
        ) {
            Row(Modifier.padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(82.dp).background(
                        Brush.linearGradient(listOf(Blue, Purple, Pink)),
                        RoundedCornerShape(50)
                    ),
                    contentAlignment = Alignment.Center
                ) { Text("✦", fontSize = 42.sp, color = Color.White) }
                Spacer(Modifier.width(18.dp))
                Column {
                    Text("Good Morning, Vijay!", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = TextDark)
                    Text("How can I help you today?", color = Color(0xFF7D76A8))
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Button(
            onClick = { nav("Chat") },
            Modifier.fillMaxWidth().padding(horizontal = 18.dp).height(58.dp),
            shape = RoundedCornerShape(22.dp),
            colors = ButtonDefaults.buttonColors(Purple)
        ) { Text("🎙  Talk to NEO AI", fontSize = 17.sp) }

        val items = listOf("AI Chat", "Voice Assistant", "Quick Tools", "My Chat", "Settings", "About NEO AI")
        LazyColumn(
            Modifier.weight(1f).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(items.size) { i ->
                val name = items[i]
                Card(
                    Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(Color.White.copy(alpha = .75f))
                ) {
                    TextButton(
                        onClick = { if (name == "My Chat" || name == "AI Chat") nav("Chat") else if (name == "Settings") nav("Settings") },
                        Modifier.fillMaxWidth().padding(8.dp)
                    ) { Text(name, Modifier.fillMaxWidth(), fontSize = 17.sp, color = TextDark) }
                }
            }
        }
        BottomNav("Home", nav)
    }
}

@Composable
fun ChatScreen(nav: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize()) {
        Header("My Chat", "NEO AI", { nav("Home") })
        LazyColumn(Modifier.weight(1f).padding(18.dp)) {
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(Color.White.copy(alpha = .82f))
                ) {
                    Text("Hello! I'm NEO AI. Ask me anything.", Modifier.padding(18.dp), color = TextDark)
                }
            }
        }
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                Modifier.weight(1f), placeholder = { Text("Message NEO AI") },
                shape = RoundedCornerShape(20.dp)
            )
            Spacer(Modifier.width(8.dp))
            Button(onClick = { text = "" }, shape = RoundedCornerShape(18.dp)) { Text("➤") }
        }
        BottomNav("Chat", nav)
    }
}

@Composable
fun SettingsScreen(nav: (String) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Header("Settings", "Customize your NEO AI experience", { nav("Home") })
        LazyColumn(
            Modifier.weight(1f).padding(horizontal = 18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Card(shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(Color.White.copy(alpha = .85f))) {
                    Row(Modifier.padding(22.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(70.dp).background(Brush.linearGradient(listOf(Blue, Purple, Pink)), RoundedCornerShape(50)), contentAlignment = Alignment.Center) {
                            Text("✦", color = Color.White, fontSize = 34.sp)
                        }
                        Spacer(Modifier.width(16.dp))
                        Column {
                            Text("NEO AI Assistant", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextDark)
                            Text("Your Smart AI Companion", color = Color(0xFF77719F))
                            Text("Free Plan", color = Purple, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            item { SettingRow("Account", "Manage your profile and account details") }
            item { SettingRow("Privacy & Security", "Control your data and privacy settings") }
            item { SettingRow("Notifications", "Manage alerts and reminders") }
            item { SettingRow("Theme", "Light • Dark • Blue • Purple") }
            item { SettingRow("App Name", "NEO AI") }
            item { SettingRow("Language", "English") }
            item { SettingRow("About", "Version 1.0 • NEO AI Assistant") }
        }
        BottomNav("Settings", nav)
    }
}

@Composable
fun SettingRow(title: String, subtitle: String) {
    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(Color.White.copy(alpha = .72f))) {
        Column(Modifier.fillMaxWidth().padding(18.dp)) {
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = TextDark)
            Text(subtitle, color = Color(0xFF7D76A8))
        }
    }
}

@Composable
fun BottomNav(selected: String, nav: (String) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(10.dp).background(Color.White.copy(alpha = .75f), RoundedCornerShape(24.dp)),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        TextButton(onClick = { nav("Home") }) { Text("⌂\nHome", color = if (selected == "Home") Purple else Color.Gray) }
        TextButton(onClick = { nav("Chat") }) { Text("💬\nChat", color = if (selected == "Chat") Purple else Color.Gray) }
        TextButton(onClick = { nav("Settings") }) { Text("⚙\nSettings", color = if (selected == "Settings") Purple else Color.Gray) }
    }
}
