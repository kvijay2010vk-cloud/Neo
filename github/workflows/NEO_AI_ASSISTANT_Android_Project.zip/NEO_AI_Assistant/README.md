# NEO AI ASSISTANT

A starter Android project matching the finalized NEO AI visual direction:
- Home
- My Chat
- Settings
- NEO AI branding
- Pastel neon / glass UI

## Build
Open the project in Android Studio on a computer and run:
`gradle assembleDebug`

The generated APK will be:
`app/build/outputs/apk/debug/app-debug.apk`

A GitHub Actions workflow is included at:
`.github/workflows/build-apk.yml`
It can build the debug APK remotely after the project is uploaded to a GitHub repository.
